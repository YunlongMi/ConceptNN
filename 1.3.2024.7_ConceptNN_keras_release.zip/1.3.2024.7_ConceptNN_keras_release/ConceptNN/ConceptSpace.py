# -*- coding: utf-8 -*-
'''
Created on Mach 12, 2021
@author: Dr. Yunlong Mi
'''
import numpy as np;
from pandas import read_csv;
from ConceptNN import cosine_similarity;
# from gevent.threading import Thread
"""
基于向量表示的数据构建概念空间
Construct concept space for each class from objects and attributes.
"""
"""
A demo for training data-kdd 
0.697,0.460,0
0.774,0.376,0
0.634,0.264,0
0.608,0.318,0
0.556,0.215,0
0.666,0.091,1
0.243,0.267,1
0.245,0.057,1
0.343,0.099,1
0.639,0.161,1
0.657,0.198,1
"""

""" 
数据划分
"""


def split_data(dataSet):
    n_samples = int(len(dataSet));  # 行数
    n_features = int(len(dataSet[0]) - 1);  # 列数,不包括标签列
    data = np.empty((n_samples, n_features));
    target = np.empty((n_samples,), dtype=np.int);
    for i, ir in enumerate(dataSet):
        data[i] = np.asarray(ir[:-1], dtype=np.float64);  # 属性列
        target[i] = np.asarray(ir[-1], dtype=np.int);  # 最后一列是整数表示的类别
    return data, target;


def sigmoid(x):
    return 1.0 / (1 + np.exp(-x));

"""
构建概念空间
"""


def construct(x_train, y_train, simThr):
    print(simThr);
    classes = np.unique(y_train);  # 类别数，返回list or array中所包含的元素，即返回不重复元素
    lists = [[] for _ in range(len(classes))];  # 构建classes数组空间
    for indexClass, value in enumerate(y_train):  # indexClass:下标; value: 值,表示第indexClass行对应的标记是0
        lists[value].append(x_train[indexClass]);  # 将下标indexClass对应的value类加入
    lineNum = 0;  countNum = 0;
    conceptSpaceIntentList = [];  # 按类别存内涵
    conceptSpaceExtentList = [];  # 按类别存外延
    conceptSpaceExtentNumList = [];  # 按类别存外延数值 大小
    for indexClass in range(len(classes)):  # 获取每一类别对应的数组7
        '''对每一个子类进行概念空间构建'''
        intentArr = [];extentArr = [];extentNum = []; neighborInstances = [];  # 用于收集领域样本集
        for line in lists[indexClass]:  # 获取一行值
            countNum += 1;  # print(countNum);
            intent = [];extent = [];  # 用于存属性（内涵）与对象（外延）
            '''任一个行对扫描一类的所有样本，获取其领域'''
            for otherLine in lists[indexClass]:  # 获取另一行值
                lineNum += 1;
#                 sim,sim2 = Euclidean_similarity.euc_sim(line, otherLine);  # 获取相似度值 sim:无压缩，Sim2:压缩
                sim = cosine_similarity.cos_sim(line, otherLine)
#                 print(sim);
#                 if sim2 <= simThr:  # 压缩后的欧拉距离[0，1]只考虑[0.5,1]即可，小于给定阈值
                if sim >= simThr:  # 余弦距离[-1,1]只考虑[0,1]即可，大于给定阈值
                    neighborInstances.append(otherLine);  # 不管有没有领域样本，但自己肯定是
                    extent.append(lineNum);  # 获取外延集
            '''将所有领域枰本求均值，获取内涵'''
            intent.append(np.mean(neighborInstances, 0));  # 获取领域均值作为内涵
            lineNum = 0; neighborInstances = [];  # 置为0，为下个样本领域计数准备
            '''将概念分类内涵与外延分别存入内涵与外延数组中'''
            intentArr.append(intent);
            extentArr.append(extent);
#             extentNum.append(sigmoid(len(extent)));
            extentNum.append(len(extent));
#             extentNum.append(len(extent)/len(lists[indexClass]));#按比例
#             print(intentArr);
#             print(extentArr);
        conceptSpaceIntentList.append(intentArr)
        conceptSpaceExtentList.append(extentArr);
        conceptSpaceExtentNumList.append(extentNum);
        intentArr = [];extentArr = [];extentNum = [];

    return conceptSpaceIntentList, conceptSpaceExtentList, conceptSpaceExtentNumList;

# Load data-kdd
# train_data = read_csv ('../data-kdd/train.csv', delimiter=',', header=None, engine='python');
# x_train, y_train = split_data(np.array(train_data));  # 将数据集与标签分离出来
# print(x_train.shape, ' ', y_train.shape)
# conceptSpaceIntentList, conceptSpaceExtentList, conceptSpaceExtentNumList = construct(x_train, y_train, 0.9);  # 构建概念空间
