"""
数据集工具类，进行数据集相关操作
"""
import pandas as pd;
import numpy as np;
import random;
from sklearn.preprocessing import LabelEncoder;

'''类别是数字型，类别给定从谁开始就从谁开始，不会转从0,1,2,...，'''
def split_data(dataSet):
      dataSet = dataSet[np.lexsort(dataSet.T)];  # 按最后一列进行排序
      n_samples = int(len(dataSet));  # 行数
      n_features = int(len(dataSet[0]) - 1);  # 列数,不包括标签列
      data = np.empty((n_samples, n_features));
      target = np.empty((n_samples,), dtype=np.int64);
      for i, ir in enumerate(dataSet):
            data[i] = np.asarray(ir[:-1], dtype=np.float64);  # 属性列
            target[i] = np.asarray(ir[-1], dtype=np.int64);  # 最后一列是整数表示的类别
      return data, target;

'''类别是符号类，将转成0,1,2,...'''
def split_data1(dataSet):
      n_samples = int(len(dataSet));  # 行数
      n_features = int(len(dataSet[0]) - 1);  # 列数,不包括标签列
      data = np.empty((n_samples, n_features));
      target = [];  # n_samples行1列
      dataSet = dataSet[np.lexsort(dataSet.T)];  # 按字母大小顺序最后一列进行排序
      for i, ir in enumerate(dataSet):
            data[i] = np.asarray(ir[:-1], dtype=np.float64);  # 属性列
            target.append(ir[-1]);  # 最后一列是整数表示的类别
      labelencoder = LabelEncoder();
      target = np.asarray(target);
      y = labelencoder.fit_transform(target);  # 字符串转数字,从0开始编码
      return data, y;

'''类别是符号类，将转成0,1,2,...'''
def split_data2(dataSet):
      n_samples = int(len(dataSet));  # 行数
      n_features = int(len(dataSet[0]) - 1);  # 列数,不包括标签列
      data = np.empty((n_samples, n_features));
      target = [];  # n_samples行1列
      for i, ir in enumerate(dataSet):
            data[i] = np.asarray(ir[:-1], dtype=np.float64);  # 属性列
            target.append(ir[-1]);  # 最后一列是整数表示的类别
      labelencoder = LabelEncoder();
      target = np.asarray(target);
      y = labelencoder.fit_transform(target);  # 字符串转数字,从0开始编码
      return data, y;

'''保存模型输出信息'''
def save_infor(loop, test_acc, predicted_prob, y_test):
      ''''
      :param loop: 第几份数据集
      :param test_acc: 准确度
      :param predicted_prob: 预测分布概率
      :param y_test: 预测标记信息【真实值】
      '''
      '''保存准确度'''
      arrAcc: list = [];
      arrAcc.append(repr(round(test_acc, 6)));
      label_save = pd.DataFrame(arrAcc);  # 默认会加上行号与列号
      label_save.to_csv('../data/result1.csv', mode='a', line_terminator=',\n', header=False,
                        index=False, );  # ,\n' 加,号换行 line_terminator

      '''保存输出概率分布信息'''
      # y_test = y_test[:, np.newaxis];  # 将一维转二维（n*1）,之前也是这样的，只是是个一维的。
      y_test = y_test.reshape(-1, 1);  # 表示1列，行数自动计算即可，与y_test = y_test[:, np.newaxis]功能一样
      pro_lab = np.hstack((predicted_prob, y_test));
      label_save = pd.DataFrame(data=pro_lab);  # 默认会加上行号与列号
      label_save.to_csv("F:/Labels/ConceptNN(Keras)/tempProb_chunk_size/prob_Label" + repr(loop + 1) + ".csv",
                        header=False, index=False, );  # 默认以‘,，’分开;header,index设为false表示是不需要行与列文件

'''保存数据块输出信息'''
def save_data_chunk_infor(loop, time_step, chunk_size, chunk_acc):
      """
      :param loop:
      :param time_step:
      :param chunk_size:
      :param chunk_acc:
      :return:
      """
      # 准确度
      arrACC: list = [];
      arrACC.append(chunk_acc);
      label_save = pd.DataFrame(arrACC);  # 默认会加上行号与列号
      label_save.to_csv('../data/chunk_size_acc' + repr(loop + 1) + '.csv', mode='a', line_terminator=',\n',
                        header=False, index=False, );  # ,\n' 加,号换行 line_terminator
      # 多少步+块大小+准确度
      arrAccInfor: list = [];
      line = repr(time_step) + "," + repr(chunk_size) + "," + repr(chunk_acc);
      arrAccInfor.append(line);
      label_save1 = pd.DataFrame(arrAccInfor);  # 默认会加上行号与列号
      label_save1.to_csv('../data/chunk_size_result' + repr(loop + 1) + '.csv', mode='a', line_terminator=',\n',
                         header=False, index=False, );  # ,\n' 加,号换行 line_terminator
