"""
@details: 配置项工具类
@author: Yunlong Mi
@time: 2024-4-28
"""
import pandas as pd;

'''功能：获取数据集， train_path为训练集文件路径， test_path为测试集文件路径'''


def get_dataset(loop: int):
    """
    :param loop:
    :return: train_data, test_data
    """
    # For demo
    # train_data = pd.read_csv('../data-kdd/train.csv', delimiter=',', header=None, engine='python');
    # test_data = pd.read_csv('../data-kdd/test.csv', delimiter=',', header=None, engine='python');
    # print(train_data.head());  # 获取数据信息

    # For ConceptNN
    train_data = pd.read_csv(
        "D:/数据信息/DataStream/real-word/Driver_drowsiness/1%training_28-28-3/our/train[" + repr(
            loop + 1) + "].csv", delimiter=',', header=None, engine='python');
    test_data = pd.read_csv(
        "D:/数据信息/DataStream/real-word/Driver_drowsiness/1%training_28-28-3/our/test[" + repr(
            loop + 1) + "].csv", delimiter=',', header=None, engine='python');

    return train_data, test_data;


'''设置神经网络输入与输出数据'''
input_dim: int = 28 * 28 * 3;  # 数据的维度
output_dim: int = 2;  # 数据的类别

'''设置神经网络输入与输出数据'''
loops: int = 20;  # 数据划分的份数
batch_size: int = 32;  # 训练中数据块大小
n_epochs: int = 100;  # epoch 的次数，即训练的次数

"""
    U: 此配置项用于模型的学习模式，可选如下参数:
    (1) "static": 用于静态学习。 
    (2) "dynamic": 用于动态学习。 
"""
U: str = "dynamic";

'''设置ConceptN相关参数'''
time_step: int = 10000;  # 通过动态学习time_step来控制整个数据流，每一步的数据大小是随机生成的
update_size: int = 100;  # 更新数据块大小；1表示 one-by-one，否则表示 chunk-by-chunk
update_epochs: int = 100;  # 当 update_size = 1时,update_epochs = 1; 当 update_size>1 时, update_epochs 自设
