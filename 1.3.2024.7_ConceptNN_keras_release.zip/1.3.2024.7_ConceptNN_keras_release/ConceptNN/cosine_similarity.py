# -*- coding: utf-8 -*-'
'''
Created on 2022/2/10

@author: MYL
'''
'''
计算余弦相似度
'''
import numpy as np;
from scipy import spatial

def cos_sim(vector_a, vector_b):
      """
      计算两个向量之间的余弦相似度
      :param vector_a: 向量 a
      :param vector_b: 向量 b
      :return: sim
      """
      #     vector_a = np.mat(vector_a)
      #     vector_b = np.mat(vector_b)
      #     num = float(vector_a * vector_b.T)
      #     denom = np.linalg.norm(vector_a) * np.linalg.norm(vector_b)
      #     sim = num / denom
      '''这种方法比上面方法快'''
      '''Usenet-2 所有一行都为0时，则需要加扰动'''
      # if np.all(vector_a == 0):  # 如向量所有分量都为0，则加点扰动
      #       value = 0.00000001;
      #       vector_a.fill(value);
      # if np.all(vector_b == 0):  # 如向量所有分量都为0，则加点扰动
      #       value = 0.00000001;
      #       vector_b.fill(value);
      sim = vector_a.dot(vector_b) / (np.linalg.norm(vector_a) * np.linalg.norm(vector_b))
      #     return sim;
      return round(sim, 15);  # python 默认浮点精度16位【两完全一样的向量在第16位上也有差别】,所以需要到15位

# def cos_sim_torch(vector_a, vector_b):
#     vec1 = torch.FloatTensor(vector_a);
#     vec2 = torch.FloatTensor(vector_b);
#  
#     cos_sim = F.cosine_similarity(vec1, vec2, dim=0)
#     return(cos_sim)

def cos_sim_scipy(vector_a, vector_b):
      cos_sim = 1 - spatial.distance.cosine(vector_a, vector_b);
      return (round(cos_sim, 5));

# a = np.array([3.3, -2.5, 1030.4, 8.8, 14.4, 22, 12.2, -2.2]);
# b = np.array([3.3, -2.5, 1030.4, 8.8, 14.4, 22, 12.2, -2.2]);
# print(cos_sim_scipy(a, b));
# print(cos_sim(a, b));
