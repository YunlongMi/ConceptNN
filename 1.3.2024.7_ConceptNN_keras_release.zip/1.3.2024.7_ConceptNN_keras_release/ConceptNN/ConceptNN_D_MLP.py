# -*- coding: utf-8 -*-
'''
Created on 2023-9-17, 2024-5-6，2024-6-23
@author: Yunlong Mi
Python 3.10; tensorflow 2.10.0; keras 2.10.0[tensorflow中自带的]
1、对相似度进行寻参；由于是生成概念空间与之间的样本存在差异，可选取一部分做为验证集
2、神经网络:MLP(features-100-64-64-classes)
3、动态更新与学习
4、考虑更新也进行one by one or chunk by chunk[1.1.2023.3_ConceptNN_release没有]
5、重新调整各模块之间关系[2024-5-6]
6、数据埠chunk_size是随机生成的[2024-7-4]
'''
import random
import tensorflow as tf;
import numpy as np;
import time;
from sklearn.model_selection import train_test_split
from tensorflow.keras import layers;
from ConceptNN import ConceptSpace, ParameterUtils, DataUtils;

''' 设置随机数种子，使训练结果可复现 '''
def setup_seed(seed):
      np.random.seed(seed)
      random.seed(seed);
      tf.random.set_seed(seed);  # 固定随机种
setup_seed(1234);  # 设置随机数种子

loops: int = ParameterUtils.loops;  # 数据划分的份数
batch_size: int = ParameterUtils.batch_size;  # 训练的块大小
n_epochs: int = ParameterUtils.n_epochs;  # epoch 的次数

for i in range(0, loops):
      print("正在运行第 {} 份样本数据".format(i + 1));
      '''1. 加载数据集'''
      train_data, test_data = ParameterUtils.get_dataset(i);  # 获取训练集与测试集
      x_train, y_train = DataUtils.split_data1(np.array(train_data));  # 将数据集与标签分离出来
      # x_grow, x_val, y_grow, y_val = train_test_split(x_train, y_train, stratify=y_train, test_size=0.2,
      #                                                 random_state=42);  # 需要按最后一列（类别）分层抽样
      x_test, y_test = DataUtils.split_data2(np.array(test_data));  # 将数据集与标签分离出来
      # 图像数据需要归到0-1之间
      # x_train /= 255;  # 归一化到0~1区间
      # x_test /= 255;  # 归一化到0~1区间

      '''2. 获取样本的权重信息'''
      simArr = [0.975, 0.98, 0.985, 0.99, 0.995, 1];  # 搜索范围[0.975, 0.98, 0.985, 0.99, 0.995, 1]
      accuracy_initalVal: int = 0;
      loss_initalVal: float = float("inf");  # 初始化值
      for sim in simArr:
            IntentList, ExtentList, ExtentNumList = ConceptSpace.construct(x_train, y_train, sim);
            x_trainConcept = np.array(IntentList[0]);  # 获取第1类概念空间内涵
            for indexClass in range(1, len(np.unique(y_train))):  # 按类别信息逐一转成数组,1,2,...class.
                  x_trainConcept = np.vstack((x_trainConcept, np.array(IntentList[indexClass])));  # 按行连接
            x_trainConcept = x_trainConcept[:, 0];  # 3维转2维，取出第一维中的所有数据

            '''3. 概念权重信息'''
            x_weight = np.array(ExtentNumList[0]);  # 获取第1类概念权重信息
            for indexClass in range(1, len(np.unique(y_train))):  # 按类别信息逐一转成数组,1,2,...class.
                  x_weight = np.hstack((x_weight, np.array(ExtentNumList[indexClass])));

            '''4. 构建模型'''
            model = tf.keras.Sequential([  # 自定义网络结构：input-100-64-64-output
                  layers.Dense(100, activation='relu', input_shape=(ParameterUtils.input_dim,)),
                  layers.Dense(64, activation='relu'),  # 中间层64个节点
                  layers.Dense(64, activation='relu'),  # 中间层64个节点
                  layers.Dense(ParameterUtils.output_dim, activation='sigmoid')  # 2表示2类, 10表示10分类
            ]);
            model.compile(optimizer=tf.keras.optimizers.Adam(),
                          # loss=tf.keras.losses.binary_crossentropy,#二分类损失函数
                          loss=tf.keras.losses.SparseCategoricalCrossentropy(),  # 多分类损失函数
                          metrics=['accuracy']);

            '''5. 训练概念神经网络'''
            model.fit(x_train, y_train, sample_weight=x_weight, batch_size=batch_size, validation_split=0.0,
                      epochs=n_epochs, verbose=0);

            '''6. 验证集上f进行验证'''  # x_train, y_train #x_val,y_val
            loss_val, accuracy_val = model.evaluate(x_train, y_train);  # 获取loss, accuracy
            print(loss_val);
            print(accuracy_val);
            if round(accuracy_val, 5) >= round(accuracy_initalVal, 5):
                  accuracy_initalVal = accuracy_val;  # 值互换
                  loss_initalVal = loss_val;
                  model.save('../models/myModel' + repr(i + 1) + '.h5');  # 保存模型
      startTime = time.time();
      '''7. 概念神经网络预测与更新'''
      model = tf.keras.models.load_model('../models/myModel' + repr(i + 1) + '.h5');  # 重新加载模型
      update_size = ParameterUtils.update_size;  # 更新数据快大小
      num_epochs = ParameterUtils.update_epochs;  # 当updateSize = 1时,num_epochs = 1; 当updateSize = chunk_size, num_epochs =自设定值.
      '''学习模式'''
      if ParameterUtils.U == "static":  # 静态学习
            loss, test_acc = model.evaluate(x_test, y_test);  # 获取loss, accuracy
            print(test_acc);
            predicted_prob = model.predict(x_test);  # 获取预测类probability
            DataUtils.save_infor(i, test_acc, predicted_prob, y_test);  # 信息输出
      elif ParameterUtils.U == "dynamic":  # 动态学习
            start: int = 0;  # 开始索引
            sum_accuracy: float = 0;
            y_predicted_prob = [];
            for t in range(ParameterUtils.time_step):
                  chunk_size = random.randint(100, 1000);  # 预测数据块大小，生成整型随机数[100,1000)
                  print("time_step_{}: {}".format(t, chunk_size));
                  end = chunk_size + start;
                  if start >= len(y_test):  # 若开始列就超过最大数据，则直接退出
                        break;
                  if end > len(y_test):  # 若生成块过大会超过最后列
                        end = len(y_test);
                  x_test_chunk = x_test[start:end];
                  y_test_chunk = y_test[start:end];
                  start += chunk_size;  # 开始列前进
                  '''预测准确度'''
                  chunk_loss, chunk_acc = model.evaluate(x_test_chunk, y_test_chunk);  # 获取loss, accuracy
                  print(chunk_acc);
                  DataUtils.save_data_chunk_infor(i, t + 1, chunk_size, chunk_acc);  # 信息输出
                  sum_accuracy += chunk_acc * len(y_test_chunk);  # 获取所有准确度
                  predicted_prob = model.predict(x_test_chunk);  # 获取预测类probability
                  '''预测类分布'''
                  if t > 0:
                        y_predicted_prob = np.vstack((y_predicted_prob, predicted_prob));
                  else:  # 获取第一块
                        y_predicted_prob = predicted_prob;
                  '''更新模型'''
                  if update_size == 1:  # 按one-by-one更新
                        model.fit(x_test_chunk, y_test_chunk, batch_size=update_size, validation_split=0.0,
                                  epochs=num_epochs, verbose=0);
                  else:  # 按chunk-by-chunk更新
                        model.fit(x_test_chunk, y_test_chunk, batch_size=update_size, validation_split=0.0,
                                  epochs=num_epochs, verbose=0);
            '''信息输出'''
            DataUtils.save_infor(i, sum_accuracy / len(y_test), y_predicted_prob, y_test);
      else:  # 提示信息
            print("Please input the type of learning  in ParameterUtils.py!");
      endTime = time.time();
      print('耗时: ', endTime - startTime);  # 秒
